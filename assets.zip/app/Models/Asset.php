<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Asset extends Model
{
    //
    protected $fillable = [
        'user_id',
        'title',
        'asset_number',
        'count',
        'description',
        'city',
        'updated_at_date',
        'user_approved',
        'admin_approved',
        'comment',
        'admin_new_comment',
        'user_new_comment',
    ];
    public function user()
    {
        return $this->belongsTo(User::class);
    }
     public function comments(): HasMany
    {
        return $this->hasMany(Comment::class);
    }

    // اگر رابطه با User هم دارید (که معمولاً دارید)
    public function owner(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id'); // فرض می کنیم ستون user_id در جدول assets است
    }
}
