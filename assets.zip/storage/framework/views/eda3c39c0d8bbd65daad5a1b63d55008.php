

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">

    <h2 class="text-2xl font-bold text-gray-800">
        اموال <?php echo e($user->name); ?>

    </h2>

    <?php if(auth()->user()->role === 'admin'): ?>
        <div class="flex gap-3">

            
            <a href="<?php echo e(route('admin.users.assets.create', $user)); ?>"
               class="bg-green-500 hover:bg-green-600 text-white px-5 py-2 rounded shadow transition duration-200">
                افزودن مال جدید
            </a>

            
            <a href="<?php echo e(route('all-users')); ?>"
               class="bg-gray-500 hover:bg-gray-600 text-white px-5 py-2 rounded shadow transition duration-200">
                بازگشت به لیست کاربران
            </a>

        </div>
    <?php endif; ?>

</div>






<div class="overflow-x-auto shadow rounded-lg">
    <table class="min-w-full bg-white table-fixed">
        <thead class="bg-gray-100 border-b">
            <tr>
                <th class="text-center p-3 font-medium text-gray-700">عنوان</th>
                <th class="text-center p-3 font-medium text-gray-700">شماره</th>
                <th class="text-center p-3 font-medium text-gray-700">تعداد</th>
                <th class="text-center p-3 font-medium text-gray-700">توضیحات</th>
                
                <th class="text-center p-3 font-medium text-gray-700">تاریخ</th>
                <th class="text-center p-3 font-medium text-gray-700"> وضعیت تایید ادمین</th>
                <th class="text-center p-3 font-medium text-gray-700"> وضعیت تایید کاربر</th>
                <th class="text-center p-3 font-medium text-gray-700">عملیات</th>
                <th class="text-center p-3 font-medium text-gray-700">کامنت</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-b hover:bg-gray-50 transition duration-150">
                    <td class="p-3 text-gray-800 text-center"><?php echo e($asset->title); ?></td>
                    <td class="p-3 text-gray-800 text-center"><?php echo e($asset->asset_number); ?></td>
                    <td class="p-3 text-gray-800 text-center"><?php echo e($asset->count); ?></td>
                    <td class="p-3 text-gray-800 text-center"><?php echo e($asset->description); ?></td>
                    
                    <td class="p-3 text-gray-800 text-center">
                        <?php echo e(\Morilog\Jalali\Jalalian::fromCarbon(\Carbon\Carbon::parse($asset->updated_at_date))->format('Y/m/d')); ?>

                    </td>
                    <td class="p-3 text-gray-800 text-center flex justify-center items-center">
                    <span class="ml-2">
                    <?php if($asset->admin_approved): ?>
                        <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">تأیید شده توسط ادمین</span>
                    <?php else: ?>
                        <span class="bg-red-100 text-red-800 px-2 py-1 rounded text-xs">عدم تأیید ادمین</span>
                    <?php endif; ?>
                    </span>
                    <span>
                        <form action="<?php echo e(route('assets.toggleAdminApproval', $asset)); ?>" method="POST">
                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                            <button type="submit"
                                class="<?php echo e($asset->admin_approved ? 'bg-red-500 hover:bg-red-600' : 'bg-green-500 hover:bg-green-600'); ?>

                                        text-white px-3 py-1 rounded">
                                <?php echo e($asset->admin_approved ? 'لغو تأیید' : 'تأیید'); ?>

                            </button>
                        </form>
                    </span>
                    </td>
                    <td class="p-3 text-gray-800 text-center">
                        <?php if($asset->user_approved): ?>
                        <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">تأیید شده توسط کاربر</span>
                        <?php else: ?>
                            <span class="bg-red-100 text-red-800 px-2 py-1 rounded text-xs">عدم تأیید کاربر</span>
                        <?php endif; ?>
                    </td>
                    <td class="p-3 text-center">
                        <a href="<?php echo e(route('admin.users.assets.edit', [$user, $asset])); ?>"
                           class="text-blue-600 hover:text-blue-800 font-medium mr-2">ویرایش</a>
                        <form action="<?php echo e(route('admin.users.assets.destroy', [$user, $asset])); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit"
                                    onclick="return confirm('آیا مطمئن هستید که می‌خواهید این مال را حذف کنید؟')"
                                    class="text-red-600 hover:text-red-800 font-medium">
                                حذف
                            </button>
                        </form>
                    </td>
                    <td class="p-3 text-center">
                        <?php if($asset->admin_new_comment): ?>
                            <span style="
                            display: inline-flex; /* استفاده از flex برای هم‌ترازی بهتر آیکون و متن */
                            align-items: center; /* عمودی وسط چین کردن */
                            background-color: #ffebee; /* پس‌زمینه قرمز روشن */
                            color: #c62828; /* رنگ متن و آیکون قرمز تیره */
                            padding: 2px 8px;
                            border-radius: 4px;
                            font-size: 0.75rem;
                            line-height: 1.2;
                            font-weight: bold;
                        ">
                            
                            &#9888;&#xFE0F; 
                            نظر جدید
                        </span>
                        <?php endif; ?>
                        <a href="<?php echo e(route('admin.users.assets.comment',[$user, $asset])); ?>"
                        class="text-blue-600 hover:text-blue-800 font-medium mr-2">کامنت</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="p-4 text-center text-gray-500">
                        هنوز مال ثبت نشده است.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    
</div>

<a href="<?php echo e(route('users.contract', $user->id)); ?>" target="_blank"
class="inline-block bg-green-100 text-green-800 px-4 py-2 mt-4 rounded-md hover:bg-indigo-700 transition">
📝 تولید فرم اموال
</a>

<div class="mt-6 border-t pt-4">
    <form action="<?php echo e(route('users.update_contract_button', $user->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PATCH'); ?> 

        <label class="inline-flex items-center cursor-pointer">
            <input type="checkbox" name="show_contract_button" value="1" class="form-checkbox h-5 w-5 text-indigo-600"
                    <?php if($user->show_contract_button): ?> checked <?php endif; ?>>
            <span class="ml-2 text-gray-700">نمایش دکمه "مشاهده فرم اموال" به این کاربر</span>
        </label>

        <button type="submit" class="ml-4 px-3 py-1 rounded-md bg-gray-200 hover:bg-gray-300 text-sm">
            ذخیره تغییرات
        </button>
    </form>
</div>


<div class="mt-4">
    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\ZahraFiles\company-assets\resources\views/admin/user-assets.blade.php ENDPATH**/ ?>