

<?php $__env->startSection('content'); ?>

<div class="w-full">
    <div class="bg-white rounded-lg shadow p-6">


    
    
    
        <div class="flex flex-wrap items-center justify-between mb-6 gap-4">
            <h4 class="text-xl font-bold">کاربران</h4>

            
            <form id="searchForm" action="<?php echo e(route('all-users')); ?>" method="GET" class="flex flex-wrap items-center gap-3">
                
                <input type="text"
                    name="search[name]"
                    value="<?php echo e(request('search.name', '')); ?>"
                    placeholder="نام کاربر..."
                    class="border border-gray-300 rounded px-3 py-1 focus:outline-none focus:ring focus:ring-blue-300 w-48">

                
                <input type="text"
                    name="search[department]"
                    value="<?php echo e(request('search.department', '')); ?>"
                    placeholder="ساختمان..."
                    class="border border-gray-300 rounded px-3 py-1 focus:outline-none focus:ring focus:ring-blue-300 w-48">

                
                <div class="relative w-48"> 
                    <select id="unit_name" name="search[unit]"
                            class="w-full px-3 py-1 border rounded-lg focus:outline-none focus:ring focus:ring-blue-300 appearance-none bg-white">
                        <option value="">-- انتخاب واحد --</option>
                        <option value="برنامه ریزی" <?php echo e(request('search.unit') == 'برنامه ریزی' ? 'selected' : ''); ?>>برنامه ریزی</option>
                        <option value="حفاظت" <?php echo e(request('search.unit') == 'حفاظت' ? 'selected' : ''); ?>>حفاظت</option>
                        <option value="IT" <?php echo e(request('search.unit') == 'IT' ? 'selected' : ''); ?>>IT</option>
                        <option value="مالی" <?php echo e(request('search.unit') == 'مالی' ? 'selected' : ''); ?>>مالی</option>
                        <option value="مدیریت" <?php echo e(request('search.unit') == 'مدیریت' ? 'selected' : ''); ?>>مدیریت</option>
                        <option value="مطالعات" <?php echo e(request('search.unit') == 'مطالعات' ? 'selected' : ''); ?>>مطالعات</option>
                        <option value="طرح و توسعه" <?php echo e(request('search.unit') == 'طرح و توسعه' ? 'selected' : ''); ?>>طرح و توسعه</option>
                        <option value="اداره امور اداری" <?php echo e(request('search.unit') == 'اداره امور اداری' ? 'selected' : ''); ?>>اداره امور اداری</option>
                    </select>
                    
                    
                </div>

                
                <button type="submit"
                        class="px-4 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700 transition">
                    جستجو
                </button>

                
                <?php if(request()->has('search') && (request('search.name') || request('search.department') || request('search.unit'))): ?>
                    <a href="<?php echo e(route('all-users')); ?>"
                    class="px-4 py-2 bg-gray-500 text-white rounded-lg shadow hover:bg-gray-600 transition">
                    نمایش همه
                    </a>
                <?php endif; ?>
            </form>


            
            <a href="<?php echo e(route('create_user')); ?>"
               class="px-4 py-2 bg-green-600  rounded-lg shadow hover:bg-green-700 transition">
               + ساخت کاربر جدید
            </a>
        </div>
    
    
    
    
    
        
        
        <?php if($newAlertsCount > 0): ?>
            <div class="mb-4 text-center">
                <a href="<?php echo e(route('admin.alerts.index')); ?>"
                class="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded shadow relative">
                    🔔 هشدار جدید (<?php echo e($newAlertsCount); ?>)
                </a>
            </div>
        <?php endif; ?>

        <div class="overflow-x-auto">
            <table class="min-w-full border border-gray-200 rounded-lg ">
                <thead class="bg-gray-100 border-b border-gray-200 ">
                    <tr>
                        <th class=" text-center p-3 font-medium text-gray-700">#</th>
                        <th class=" text-center p-3 font-medium text-gray-700">نام</th>
                        <th class=" text-center p-3 font-medium text-gray-700">نام کاربری</th>
                        <th class=" text-center p-3 font-medium text-gray-700">ساختمان</th>
                        <th class=" text-center p-3 font-medium text-gray-700">واحد</th>
                        <th class=" text-center p-3 font-medium text-gray-700">شماره اتاق</th>
                        <th class=" text-center p-3 font-medium text-gray-700">طبقه</th>
                        <th class=" text-center p-3 font-medium text-gray-700">امکان ثبت اموال توسط کاربر</th>
                        <th class=" text-center p-3 font-medium text-gray-700">عملیات </th>
                        <th class="text-center p-3 font-medium text-gray-700">لیست اموال</th>

                    </tr>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b hover:bg-gray-50 transition ">
                            <td class="p-3 text-center text-gray-800"><?php echo e($user->id); ?></td>
                            <td class="p-3 text-center text-gray-800">
                                 <?php if($user->new_comment): ?>
                                    <span style="
                                        display: inline-flex; /* استفاده از flex برای هم‌ترازی بهتر آیکون و متن */
                                        align-items: center; /* عمودی وسط چین کردن */
                                        background-color: #ffebee; /* پس‌زمینه قرمز روشن */
                                        color: #c62828; /* رنگ متن و آیکون قرمز تیره */
                                        padding: 2px 8px;
                                        border-radius: 4px;
                                        font-size: 0.75rem;
                                        line-height: 1.2;
                                        font-weight: bold;
                                    ">
                                        
                                        &#9888;&#xFE0F; 
                                        نظر جدید
                                    </span>
                                <?php endif; ?>
                                <?php echo e($user->name); ?></td>
                            <td class="p-3 text-center text-gray-800"><?php echo e($user->email); ?></td>
                            <td class="p-3 text-center text-gray-800"><?php echo e($user->department); ?></td>
                            <td class="p-3 text-center text-gray-800"><?php echo e($user->unit); ?></td>
                            <td class="p-3 text-center text-gray-800"><?php echo e($user->room_number); ?></td>
                            <td class="p-3 text-center text-gray-800"><?php echo e($user->floor); ?></td>
                            <td class="p-3 text-center text-gray-800">
                            <?php if($user->role!="admin"): ?>
                            <form action="<?php echo e(route('admin.users.toggleEditing', $user)); ?>" method="POST" class="inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <button type="submit" class="
                                    <?php echo e($user->allow_editing
                                        ? 'bg-red-500 hover:bg-red-600 text-white focus:ring-red-400'
                                        : 'bg-green-500 hover:bg-green-600 text-white focus:ring-green-400'); ?>

                                    font-semibold py-2 px-4 rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-opacity-75 transition duration-150 ease-in-out text-xs
                                ">
                                    <?php echo e($user->allow_editing ? 'غیرفعال سازی ثبت اموال' : 'فعال سازی ثبت اموال'); ?>

                                </button>
                            </form>
                            <?php endif; ?>
                            </td>
                            <td class="p-3 text-center text-gray-800 flex items-center justify-center ">
                                <?php if($user->role!="admin"): ?>
                                <a href="<?php echo e(route('edit-user', $user->id)); ?>"
                                class="px-3 py-1.5 bg-blue-600 text-white text-sm rounded-md shadow hover:bg-blue-700 transition ml-2">
                                ویرایش کاربر
                                </a>

                                
                                <form action="<?php echo e(route('delete-user', $user->id)); ?>" method="POST" onsubmit="return confirm('آیا از حذف کاربر مطمئن هستید؟');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?> 
                                    <button type="submit" class="px-3 py-1.5 bg-red-600 text-white text-sm rounded-md shadow hover:bg-red-700 transition">
                                        حذف کاربر
                                    </button>
                                </form>
                                <?php endif; ?>
                            </td>
                            <td class="p-3 text-center text-gray-800">
                                <?php if($user->role!="admin"): ?>
                                <a href= "<?php echo e(route('admin.users.showUserAssets', $user->id)); ?>"
                                class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-1 rounded shadow transition duration-200">
                                مشاهده اموال
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

    </div>
</div>

 <div class="container  p-4 w-1/2 w-50 float-right ">
            

            

            <div class="bg-white p-6 rounded-lg shadow-md flex items-center justify-between mb-6 ">
                
                
                <form action="<?php echo e(route('admin.users.bulk_allow_editing')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="mb-4">
                        <h5 class="font-bold mb-6">مدیریت دسترسی کاربران بر اساس واحد</h5>
                        <label for="unit_name" class="block text-gray-700 text-sm font-bold mb-2">انتخاب واحد:</label>
                        
                        <select id="unit_name" name="unit_name" 
                            
                            class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring focus:ring-blue-300">
                            <option value="">-- لطفا یک واحد انتخاب کنید --</option>
                            <option value="برنامه ریزی">برنامه ریزی</option>
                            <option value="حفاظت">حفاظت</option>
                            <option value="IT">IT</option>
                            <option value="مالی">مالی</option>
                            <option value="مدیریت">مدیریت</option>
                            <option value="مطالعات">مطالعات</option>
                            <option value="طرح و توسعه">طرح و توسعه</option>
                            <option value="اداره امور اداری">اداره امور اداری</option>
                            <option value="منابع انسانی و پشتیبانی">منابع انسانی و پشتیبانی</option>
                            <option value="مدیریت منابع انسانی">مدیریت منابع انسانی</option>
                        </select>
                        <?php $__errorArgs = ['unit_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs italic mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-4">
                        <label for="action" class="block text-gray-700 text-sm font-bold mb-2">عملیات:</label>
                        <select name="action" id="action"
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                            <option value="enable">فعال سازی ثبت اموال برای همه</option>
                            <option value="disable">غیرفعال سازی ثبت اموال برای همه</option>
                        </select>
                         <?php $__errorArgs = ['action'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-500 text-xs italic mt-1"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="flex items-center justify-between">
                        <button type="submit"
                                class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                            اجرای عملیات
                        </button>
                    </div>
                </form>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\ZahraFiles\company-assets\resources\views/admin/users/all-users.blade.php ENDPATH**/ ?>