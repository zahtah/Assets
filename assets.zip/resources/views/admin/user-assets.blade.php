@extends('layouts.app')

@section('content')
<div class="flex justify-between items-center mb-6">

    <h2 class="text-2xl font-bold text-gray-800">
        اموال {{ $user->name }}
    </h2>

    @if(auth()->user()->role === 'admin')
        <div class="flex gap-3">

            {{-- دکمه افزودن مال --}}
            <a href="{{ route('admin.users.assets.create', $user) }}"
               class="bg-green-500 hover:bg-green-600 text-white px-5 py-2 rounded shadow transition duration-200">
                افزودن مال جدید
            </a>

            {{-- دکمه بازگشت --}}
            <a href="{{ route('all-users') }}"
               class="bg-gray-500 hover:bg-gray-600 text-white px-5 py-2 rounded shadow transition duration-200">
                بازگشت به لیست کاربران
            </a>

        </div>
    @endif

</div>

{{-- <div class="flex flex-col md:flex-row justify-between items-center mb-6">
    <h2 class="text-2xl font-bold text-gray-800 mb-4 md:mb-0">
        اموال {{ $user->name }}
    </h2> 
    <a href="{{ route('admin.users.assets.create', $user) }}"
       class="bg-green-500 hover:bg-green-600 text-white px-5 py-2 rounded shadow transition duration-200">
        ثبت مال جدید
    </a> 
 </div> --}}

{{-- پیام موفقیت --}}
{{-- @if(session('success'))
    <div class="mb-4 p-3 bg-green-100 text-green-700 rounded shadow">
        {{ session('success') }}
    </div>
@endif --}}

<div class="overflow-x-auto shadow rounded-lg">
    <table class="min-w-full bg-white table-fixed">
        <thead class="bg-gray-100 border-b">
            <tr>
                <th class="text-center p-3 font-medium text-gray-700">عنوان</th>
                <th class="text-center p-3 font-medium text-gray-700">شماره</th>
                <th class="text-center p-3 font-medium text-gray-700">تعداد</th>
                <th class="text-center p-3 font-medium text-gray-700">توضیحات</th>
                {{-- <th class="text-center p-3 font-medium text-gray-700">ستاد</th> --}}
                <th class="text-center p-3 font-medium text-gray-700">تاریخ</th>
                <th class="text-center p-3 font-medium text-gray-700"> وضعیت تایید ادمین</th>
                <th class="text-center p-3 font-medium text-gray-700"> وضعیت تایید کاربر</th>
                <th class="text-center p-3 font-medium text-gray-700">عملیات</th>
                <th class="text-center p-3 font-medium text-gray-700">کامنت</th>
            </tr>
        </thead>
        <tbody>
            @forelse($assets as $asset)
                <tr class="border-b hover:bg-gray-50 transition duration-150">
                    <td class="p-3 text-gray-800 text-center">{{ $asset->title }}</td>
                    <td class="p-3 text-gray-800 text-center">{{ $asset->asset_number }}</td>
                    <td class="p-3 text-gray-800 text-center">{{ $asset->count }}</td>
                    <td class="p-3 text-gray-800 text-center">{{ $asset->description }}</td>
                    {{-- <td class="p-3 text-gray-800 text-center">{{ $asset->city }}</td> --}}
                    <td class="p-3 text-gray-800 text-center">
                        {{ \Morilog\Jalali\Jalalian::fromCarbon(\Carbon\Carbon::parse($asset->updated_at_date))->format('Y/m/d') }}
                    </td>
                    <td class="p-3 text-gray-800 text-center flex justify-center items-center">
                    <span class="ml-2">
                    @if ($asset->admin_approved)
                        <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">تأیید شده توسط ادمین</span>
                    @else
                        <span class="bg-red-100 text-red-800 px-2 py-1 rounded text-xs">عدم تأیید ادمین</span>
                    @endif
                    </span>
                    <span>
                        <form action="{{ route('assets.toggleAdminApproval', $asset) }}" method="POST">
                            @csrf @method('PATCH')
                            <button type="submit"
                                class="{{ $asset->admin_approved ? 'bg-red-500 hover:bg-red-600' : 'bg-green-500 hover:bg-green-600' }}
                                        text-white px-3 py-1 rounded">
                                {{ $asset->admin_approved ? 'لغو تأیید' : 'تأیید' }}
                            </button>
                        </form>
                    </span>
                    </td>
                    <td class="p-3 text-gray-800 text-center">
                        @if ($asset->user_approved)
                        <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">تأیید شده توسط کاربر</span>
                        @else
                            <span class="bg-red-100 text-red-800 px-2 py-1 rounded text-xs">عدم تأیید کاربر</span>
                        @endif
                    </td>
                    <td class="p-3 text-center">
                        <a href="{{ route('admin.users.assets.edit', [$user, $asset]) }}"
                           class="text-blue-600 hover:text-blue-800 font-medium mr-2">ویرایش</a>
                        <form action="{{ route('admin.users.assets.destroy', [$user, $asset]) }}" method="POST" class="inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit"
                                    onclick="return confirm('آیا مطمئن هستید که می‌خواهید این مال را حذف کنید؟')"
                                    class="text-red-600 hover:text-red-800 font-medium">
                                حذف
                            </button>
                        </form>
                    </td>
                    <td class="p-3 text-center">
                        @if ($asset->admin_new_comment)
                            <span style="
                            display: inline-flex; /* استفاده از flex برای هم‌ترازی بهتر آیکون و متن */
                            align-items: center; /* عمودی وسط چین کردن */
                            background-color: #ffebee; /* پس‌زمینه قرمز روشن */
                            color: #c62828; /* رنگ متن و آیکون قرمز تیره */
                            padding: 2px 8px;
                            border-radius: 4px;
                            font-size: 0.75rem;
                            line-height: 1.2;
                            font-weight: bold;
                        ">
                            {{-- کاراکتر یونیکد علامت هشدار مثلثی --}}
                            &#9888;&#xFE0F; {{-- &#9888; = ⚠️ --}}
                            نظر جدید
                        </span>
                        @endif
                        <a href="{{ route('admin.users.assets.comment',[$user, $asset]) }}"
                        class="text-blue-600 hover:text-blue-800 font-medium mr-2">کامنت</a>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="5" class="p-4 text-center text-gray-500">
                        هنوز مال ثبت نشده است.
                    </td>
                </tr>
            @endforelse
        </tbody>
    </table>
    
</div>

<a href="{{ route('users.contract', $user->id) }}" target="_blank"
class="inline-block bg-green-100 text-green-800 px-4 py-2 mt-4 rounded-md hover:bg-indigo-700 transition">
📝 تولید فرم اموال
</a>

<div class="mt-6 border-t pt-4">
    <form action="{{ route('users.update_contract_button', $user->id) }}" method="POST">
        @csrf
        @method('PATCH') {{-- چون داریم یک فیلد را آپدیت می کنیم --}}

        <label class="inline-flex items-center cursor-pointer">
            <input type="checkbox" name="show_contract_button" value="1" class="form-checkbox h-5 w-5 text-indigo-600"
                    @if($user->show_contract_button) checked @endif>
            <span class="ml-2 text-gray-700">نمایش دکمه "مشاهده فرم اموال" به این کاربر</span>
        </label>

        <button type="submit" class="ml-4 px-3 py-1 rounded-md bg-gray-200 hover:bg-gray-300 text-sm">
            ذخیره تغییرات
        </button>
    </form>
</div>

{{-- Pagination --}}
<div class="mt-4">
    {{-- {{ $assets->links('vendor.pagination.tailwind') }} --}}
</div>

@endsection