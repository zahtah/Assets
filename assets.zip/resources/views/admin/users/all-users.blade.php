@extends('layouts.app')

@section('content')

<div class="w-full">
    <div class="bg-white rounded-lg shadow p-6">


    {{-- --}}
    
    {{-- هدر صفحه و فرم جستجو --}}
        <div class="flex flex-wrap items-center justify-between mb-6 gap-4">
            <h4 class="text-xl font-bold">کاربران</h4>

            {{-- فرم جستجو --}}
            <form id="searchForm" action="{{ route('all-users') }}" method="GET" class="flex flex-wrap items-center gap-3">
                {{-- فیلد نام کاربر --}}
                <input type="text"
                    name="search[name]"
                    value="{{ request('search.name', '') }}"
                    placeholder="نام کاربر..."
                    class="border border-gray-300 rounded px-3 py-1 focus:outline-none focus:ring focus:ring-blue-300 w-48">

                {{-- فیلد ساختمان --}}
                <input type="text"
                    name="search[department]"
                    value="{{ request('search.department', '') }}"
                    placeholder="ساختمان..."
                    class="border border-gray-300 rounded px-3 py-1 focus:outline-none focus:ring focus:ring-blue-300 w-48">

                {{-- فیلد واحد (جدید) --}}
                <div class="relative w-48"> {{-- Wrapper برای select --}}
                    <select id="unit_name" name="search[unit]"
                            class="w-full px-3 py-1 border rounded-lg focus:outline-none focus:ring focus:ring-blue-300 appearance-none bg-white">
                        <option value="">-- انتخاب واحد --</option>
                        <option value="برنامه ریزی" {{ request('search.unit') == 'برنامه ریزی' ? 'selected' : '' }}>برنامه ریزی</option>
                        <option value="حفاظت" {{ request('search.unit') == 'حفاظت' ? 'selected' : '' }}>حفاظت</option>
                        <option value="IT" {{ request('search.unit') == 'IT' ? 'selected' : '' }}>IT</option>
                        <option value="مالی" {{ request('search.unit') == 'مالی' ? 'selected' : '' }}>مالی</option>
                        <option value="مدیریت" {{ request('search.unit') == 'مدیریت' ? 'selected' : '' }}>مدیریت</option>
                        <option value="مطالعات" {{ request('search.unit') == 'مطالعات' ? 'selected' : '' }}>مطالعات</option>
                        <option value="طرح و توسعه" {{ request('search.unit') == 'طرح و توسعه' ? 'selected' : '' }}>طرح و توسعه</option>
                        <option value="اداره امور اداری" {{ request('search.unit') == 'اداره امور اداری' ? 'selected' : '' }}>اداره امور اداری</option>
                    </select>
                    {{-- آیکون فلش برای select --}}
                    {{-- <div class="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                        <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 9l4-4 4 4m0 6l-4 4-4-4"></path>
                        </svg>
                    </div> --}}
                </div>

                {{-- دکمه جستجو --}}
                <button type="submit"
                        class="px-4 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700 transition">
                    جستجو
                </button>

                {{-- دکمه نمایش همه (فقط زمانی نمایش داده می‌شود که پارامتر جستجو وجود داشته باشد) --}}
                @if(request()->has('search') && (request('search.name') || request('search.department') || request('search.unit')))
                    <a href="{{ route('all-users') }}"
                    class="px-4 py-2 bg-gray-500 text-white rounded-lg shadow hover:bg-gray-600 transition">
                    نمایش همه
                    </a>
                @endif
            </form>


            {{-- دکمه ساخت کاربر جدید --}}
            <a href="{{ route('create_user') }}"
               class="px-4 py-2 bg-green-600  rounded-lg shadow hover:bg-green-700 transition">
               + ساخت کاربر جدید
            </a>
        </div>
    
    
    
    
    {{-- --}}
        
        {{-- <div class="flex items-center justify-between mb-6">
            <h4 class="text-xl font-bold">کاربران</h4>

            <a href="{{ route('create_user') }}"
               class="px-4 py-2 bg-green-600 text-black rounded-lg shadow hover:bg-green-700 transition">
               + ساخت کاربر جدید
            </a>
        </div> --}}
        @if($newAlertsCount > 0)
            <div class="mb-4 text-center">
                <a href="{{ route('admin.alerts.index') }}"
                class="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded shadow relative">
                    🔔 هشدار جدید ({{ $newAlertsCount }})
                </a>
            </div>
        @endif

        <div class="overflow-x-auto">
            <table class="min-w-full border border-gray-200 rounded-lg ">
                <thead class="bg-gray-100 border-b border-gray-200 ">
                    <tr>
                        <th class=" text-center p-3 font-medium text-gray-700">#</th>
                        <th class=" text-center p-3 font-medium text-gray-700">نام</th>
                        <th class=" text-center p-3 font-medium text-gray-700">نام کاربری</th>
                        <th class=" text-center p-3 font-medium text-gray-700">ساختمان</th>
                        <th class=" text-center p-3 font-medium text-gray-700">واحد</th>
                        <th class=" text-center p-3 font-medium text-gray-700">شماره اتاق</th>
                        <th class=" text-center p-3 font-medium text-gray-700">طبقه</th>
                        <th class=" text-center p-3 font-medium text-gray-700">امکان ثبت اموال توسط کاربر</th>
                        <th class=" text-center p-3 font-medium text-gray-700">عملیات </th>
                        <th class="text-center p-3 font-medium text-gray-700">لیست اموال</th>

                    </tr>
                </thead>

                <tbody>
                    @foreach ($users as $user)
                        <tr class="border-b hover:bg-gray-50 transition ">
                            <td class="p-3 text-center text-gray-800">{{ $user->id }}</td>
                            <td class="p-3 text-center text-gray-800">
                                 @if ($user->new_comment)
                                    <span style="
                                        display: inline-flex; /* استفاده از flex برای هم‌ترازی بهتر آیکون و متن */
                                        align-items: center; /* عمودی وسط چین کردن */
                                        background-color: #ffebee; /* پس‌زمینه قرمز روشن */
                                        color: #c62828; /* رنگ متن و آیکون قرمز تیره */
                                        padding: 2px 8px;
                                        border-radius: 4px;
                                        font-size: 0.75rem;
                                        line-height: 1.2;
                                        font-weight: bold;
                                    ">
                                        {{-- کاراکتر یونیکد علامت هشدار مثلثی --}}
                                        &#9888;&#xFE0F; {{-- &#9888; = ⚠️ --}}
                                        نظر جدید
                                    </span>
                                @endif
                                {{ $user->name }}</td>
                            <td class="p-3 text-center text-gray-800">{{ $user->email }}</td>
                            <td class="p-3 text-center text-gray-800">{{ $user->department }}</td>
                            <td class="p-3 text-center text-gray-800">{{ $user->unit }}</td>
                            <td class="p-3 text-center text-gray-800">{{ $user->room_number }}</td>
                            <td class="p-3 text-center text-gray-800">{{ $user->floor }}</td>
                            <td class="p-3 text-center text-gray-800">
                            @if ($user->role!="admin")
                            <form action="{{ route('admin.users.toggleEditing', $user) }}" method="POST" class="inline-block">
                                @csrf
                                @method('PATCH')
                                <button type="submit" class="
                                    {{ $user->allow_editing
                                        ? 'bg-red-500 hover:bg-red-600 text-white focus:ring-red-400'
                                        : 'bg-green-500 hover:bg-green-600 text-white focus:ring-green-400'
                                    }}
                                    font-semibold py-2 px-4 rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-opacity-75 transition duration-150 ease-in-out text-xs
                                ">
                                    {{ $user->allow_editing ? 'غیرفعال سازی ثبت اموال' : 'فعال سازی ثبت اموال' }}
                                </button>
                            </form>
                            @endif
                            </td>
                            <td class="p-3 text-center text-gray-800 flex items-center justify-center ">
                                @if ($user->role!="admin")
                                <a href="{{ route('edit-user', $user->id) }}"
                                class="px-3 py-1.5 bg-blue-600 text-white text-sm rounded-md shadow hover:bg-blue-700 transition ml-2">
                                ویرایش کاربر
                                </a>

                                {{-- <a href="#"
                                class="px-3 py-1.5 bg-red-600 text-white text-sm rounded-md shadow hover:bg-red-700 transition">
                                حذف
                                </a> --}}
                                <form action="{{ route('delete-user', $user->id) }}" method="POST" onsubmit="return confirm('آیا از حذف کاربر مطمئن هستید؟');">
                                    @csrf
                                    @method('DELETE') {{-- یا POST اگر route شما از POST استفاده می کند --}}
                                    <button type="submit" class="px-3 py-1.5 bg-red-600 text-white text-sm rounded-md shadow hover:bg-red-700 transition">
                                        حذف کاربر
                                    </button>
                                </form>
                                @endif
                            </td>
                            <td class="p-3 text-center text-gray-800">
                                @if ($user->role!="admin")
                                <a href= "{{ route('admin.users.showUserAssets', $user->id) }}"
                                class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-1 rounded shadow transition duration-200">
                                مشاهده اموال
                                </a>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

    </div>
</div>

 <div class="container  p-4 w-1/2 w-50 float-right ">
            

            {{-- ... (بخش نمایش پیام‌های success/error مانند قبل) ... --}}

            <div class="bg-white p-6 rounded-lg shadow-md flex items-center justify-between mb-6 ">
                
                {{-- action را به route جدیدی که در ادامه تعریف می‌کنیم تغییر دهید --}}
                <form action="{{ route('admin.users.bulk_allow_editing') }}" method="POST">
                    @csrf

                    <div class="mb-4">
                        <h5 class="font-bold mb-6">مدیریت دسترسی کاربران بر اساس واحد</h5>
                        <label for="unit_name" class="block text-gray-700 text-sm font-bold mb-2">انتخاب واحد:</label>
                        {{-- <select name="department_name" id="department_name"
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                            <option value="">-- لطفا یک دپارتمان انتخاب کنید --</option>
                            {{-- لیستی از دپارتمان‌های منحصر به فرد از کنترلر می‌آید 
                            @foreach ($departmentNames as $deptName)
                                <option value="{{ $deptName }}">{{ $deptName }}</option>
                            @endforeach
                        </select> --}}
                        <select id="unit_name" name="unit_name" 
                            
                            class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring focus:ring-blue-300">
                            <option value="">-- لطفا یک واحد انتخاب کنید --</option>
                            <option value="برنامه ریزی">برنامه ریزی</option>
                            <option value="حفاظت">حفاظت</option>
                            <option value="IT">IT</option>
                            <option value="مالی">مالی</option>
                            <option value="مدیریت">مدیریت</option>
                            <option value="مطالعات">مطالعات</option>
                            <option value="طرح و توسعه">طرح و توسعه</option>
                            <option value="اداره امور اداری">اداره امور اداری</option>
                            <option value="منابع انسانی و پشتیبانی">منابع انسانی و پشتیبانی</option>
                            <option value="مدیریت منابع انسانی">مدیریت منابع انسانی</option>
                        </select>
                        @error('unit_name')
                            <p class="text-red-500 text-xs italic mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="mb-4">
                        <label for="action" class="block text-gray-700 text-sm font-bold mb-2">عملیات:</label>
                        <select name="action" id="action"
                                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                            <option value="enable">فعال سازی ثبت اموال برای همه</option>
                            <option value="disable">غیرفعال سازی ثبت اموال برای همه</option>
                        </select>
                         @error('action')
                            <p class="text-red-500 text-xs italic mt-1">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="flex items-center justify-between">
                        <button type="submit"
                                class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
                            اجرای عملیات
                        </button>
                    </div>
                </form>
            </div>
        </div>

@endsection
