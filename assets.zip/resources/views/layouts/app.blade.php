<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>سیستم اموال شرکت</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    @vite(['resources/css/app.css','resources/js/app.js'])
</head>
<body class="bg-gray-100">

<nav class="bg-white shadow p-4 flex justify-between">
    <div class="flex items-center gap-4">
        @if(auth()->user()->role === 'user')
            <a href="{{ route('assets.index') }}"
            class="text-black-600 px-4 py-2 bg-blue-600  font-bold rounded-lg shadow hover:bg-blue-700 transition">
                سیستم اموال
            </a>
            <li class="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg shadow hover:bg-gray-300 transition">
                <a href="{{ route('profile.edit') }}">پروفایل من</a>
            </li>
        @endif
        @if(auth()->user()->role === 'admin')
            <div class="relative group inline-block">
                <a href="{{ route('admin.alerts.index') }}"
                class="text-gray-800 rounded-lg p-2 shadow hover:bg-gray-300 transition">
                    🔔
                </a>

                <div class="absolute left-1/2 -translate-x-1/2 top-full mt-2
                            px-3 py-1.5 text-black text-xs rounded
                            opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    هشدارها
                </div>
            </div>


            <a href="{{ route('admin.export.assets') }}" 
            class="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg shadow hover:bg-gray-300 transition">
            دریافت خروجی اکسل اموال
            </a>
            <a href="{{ route('all-users') }}" 
            class="px-4 font-bold py-2 bg-gray-200 text-blue-600 rounded-lg shadow hover:bg-gray-300 transition">
           مدیریت کاربران و اموال
            </a>
            <form action="{{ route('import.users.assets') }}" method="POST" enctype="multipart/form-data" class="px-4 font-bold py-2 bg-gray-200 text-blue-600 rounded-lg shadow hover:bg-gray-300 transition">>
                @csrf
                <label>📂 آپلود فایل اکسل:</label>
                <input type="file" name="excel_file" required>
                <button type="submit">بارگذاری</button>
            </form>

        @endif
        

    </div>
    
    <div class="flex items-center gap-4">
        <span>سلام {{ auth()->user()->name }}</span>

        @if(auth()->user()->role === 'admin')
            <a href="{{ route('admin.users') }}" class="text-gray-800 px-4 py-2 bg-gray-200  rounded-lg shadow hover:bg-blue-700 transition">لاگ کاربران  </a>
        @endif

        <form method="POST" action="{{ route('logout') }}">
            @csrf
            <button class="text-red-600 px-4 py-2 bg-gray-200 font-bold rounded-lg shadow hover:bg-blue-700 transition">خروج</button>
        </form>
    </div>
</nav>

<div class="container mx-auto p-6">
    @if(session('success'))
        <div class="bg-green-200 text-green-800 p-3 rounded mb-4">
            {{ session('success') }}
        </div>
    @endif

    @yield('content')
</div>

</body>
</html>