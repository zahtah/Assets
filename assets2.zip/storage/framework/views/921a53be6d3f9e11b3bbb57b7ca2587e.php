<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto">
    <h2 class="text-2xl font-bold text-gray-800 mb-2">ثبت مال جدید در انبار</h2>
    <p class="text-gray-600 text-sm mb-6">این مال بدون مالک ثبت می‌شود و بعداً از صفحه‌ی انبار می‌توان آن را به کاربر اختصاص داد.</p>

    <form method="POST" action="<?php echo e(route('warehouse.assets.store')); ?>" class="bg-white p-6 rounded shadow">
        <?php echo csrf_field(); ?>

        <div class="mb-4">
            <label class="block mb-1" for="title">عنوان مال</label>
            <input type="text" id="title" name="title" value="<?php echo e(old('title')); ?>" class="w-full border p-2 rounded" required autofocus>
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red-600 mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-4">
            <label class="block mb-1" for="asset_number">شماره اموال</label>
            <input type="text" id="asset_number" name="asset_number" value="<?php echo e(old('asset_number')); ?>" class="w-full border p-2 rounded" required>
            <?php $__errorArgs = ['asset_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red-600 mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-4">
            <label class="block mb-1" for="count">تعداد</label>
            <input type="number" id="count" name="count" min="1" value="<?php echo e(old('count', 1)); ?>" class="w-full border p-2 rounded">
            <?php $__errorArgs = ['count'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red-600 mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mb-4">
            <label class="block mb-1" for="description">توضیحات</label>
            <input type="text" id="description" name="description" value="<?php echo e(old('description')); ?>" class="w-full border p-2 rounded">
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-red-600 mt-1"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded">ثبت</button>
        <button type="submit" name="add_another" value="1" class="bg-blue-500 text-white px-4 py-2 rounded">ثبت و افزودن مال بعدی</button>
        <a href="<?php echo e(route('warehouse.index')); ?>" class="bg-gray-300 text-black px-4 py-2 rounded">انصراف</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\ZahraFiles\company-assets\resources\views/warehouse/create.blade.php ENDPATH**/ ?>