<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>سیستم اموال شرکت</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
</head>
<body class="bg-gray-100">

<nav class="bg-white shadow p-4 flex justify-between">
    <div class="flex items-center gap-4">
        <?php if(auth()->user()->role === 'user'): ?>
            <a href="<?php echo e(route('assets.index')); ?>"
            class="text-black-600 px-4 py-2 bg-blue-600  font-bold rounded-lg shadow hover:bg-blue-700 transition">
                سیستم اموال
            </a>
            <li class="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg shadow hover:bg-gray-300 transition">
                <a href="<?php echo e(route('profile.edit')); ?>">پروفایل من</a>
            </li>
        <?php endif; ?>
        <?php if(auth()->user()->role === 'warehouse'): ?>
            <a href="<?php echo e(route('warehouse.index')); ?>"
            class="text-black-600 px-4 py-2 bg-blue-600 font-bold rounded-lg shadow hover:bg-blue-700 transition">
                واحد انبار
            </a>
        <?php endif; ?>
        <?php if(auth()->user()->role === 'admin'): ?>
            <div class="relative group inline-block">
                <a href="<?php echo e(route('admin.alerts.index')); ?>"
                class="text-gray-800 rounded-lg p-2 shadow hover:bg-gray-300 transition">
                    🔔
                </a>

                <div class="absolute left-1/2 -translate-x-1/2 top-full mt-2
                            px-3 py-1.5 text-black text-xs rounded
                            opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    هشدارها
                </div>
            </div>


            <a href="<?php echo e(route('admin.export.assets')); ?>" 
            class="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg shadow hover:bg-gray-300 transition">
            دریافت خروجی اکسل اموال
            </a>
            <a href="<?php echo e(route('all-users')); ?>" 
            class="px-4 font-bold py-2 bg-gray-200 text-blue-600 rounded-lg shadow hover:bg-gray-300 transition">
           مدیریت کاربران و اموال
            </a>
            <a href="<?php echo e(route('admin.edited-assets')); ?>"
            class="px-4 font-bold py-2 bg-gray-200 text-blue-600 rounded-lg shadow hover:bg-gray-300 transition">
           اموال ویرایش‌شده
            </a>
            <a href="<?php echo e(route('warehouse.index')); ?>"
            class="px-4 font-bold py-2 bg-gray-200 text-blue-600 rounded-lg shadow hover:bg-gray-300 transition">
           انبار
            </a>
            <form action="<?php echo e(route('import.users.assets')); ?>" method="POST" enctype="multipart/form-data" class="px-4 font-bold py-2 bg-gray-200 text-blue-600 rounded-lg shadow hover:bg-gray-300 transition">>
                <?php echo csrf_field(); ?>
                <label>📂 آپلود فایل اکسل:</label>
                <input type="file" name="excel_file" required>
                <button type="submit">بارگذاری</button>
            </form>

        <?php endif; ?>
        

    </div>
    
    <div class="flex items-center gap-4">
        <span>سلام <?php echo e(auth()->user()->name); ?></span>

        <?php if(auth()->user()->role === 'admin'): ?>
            <a href="<?php echo e(route('admin.users')); ?>" class="text-gray-800 px-4 py-2 bg-gray-200  rounded-lg shadow hover:bg-blue-700 transition">لاگ کاربران  </a>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button class="text-red-600 px-4 py-2 bg-gray-200 font-bold rounded-lg shadow hover:bg-blue-700 transition">خروج</button>
        </form>
    </div>
</nav>

<div class="container mx-auto p-6">
    <?php if(session('success')): ?>
        <div class="bg-green-200 text-green-800 p-3 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="p-3 rounded mb-4" style="background-color:#fecaca;color:#991b1b;">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>
</div>

</body>
</html><?php /**PATH D:\ZahraFiles\company-assets\resources\views/layouts/app.blade.php ENDPATH**/ ?>