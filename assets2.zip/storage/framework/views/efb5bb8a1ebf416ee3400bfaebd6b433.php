
<?php if($paginator->hasPages()): ?>
    <?php
        $current = $paginator->currentPage();
        $last    = $paginator->lastPage();
        $start   = max(1, $current - 2);
        $end     = min($last, $current + 2);
        $btn     = 'display:inline-block;min-width:34px;padding:4px 10px;margin:0 2px;border:1px solid #d1d5db;border-radius:6px;text-align:center;background:#fff;color:#1f2937;text-decoration:none;';
        $active  = 'display:inline-block;min-width:34px;padding:4px 10px;margin:0 2px;border:1px solid #2563eb;border-radius:6px;text-align:center;background:#2563eb;color:#fff;';
        $off     = 'display:inline-block;min-width:34px;padding:4px 10px;margin:0 2px;border:1px solid #e5e7eb;border-radius:6px;text-align:center;background:#f9fafb;color:#9ca3af;';
    ?>
    <nav style="margin-top:16px;text-align:center;" aria-label="صفحه‌بندی">
        <?php if($paginator->onFirstPage()): ?>
            <span style="<?php echo e($off); ?>">قبلی</span>
        <?php else: ?>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>" style="<?php echo e($btn); ?>">قبلی</a>
        <?php endif; ?>

        <?php if($start > 1): ?>
            <a href="<?php echo e($paginator->url(1)); ?>" style="<?php echo e($btn); ?>">1</a>
            <?php if($start > 2): ?> <span>…</span> <?php endif; ?>
        <?php endif; ?>

        <?php for($i = $start; $i <= $end; $i++): ?>
            <?php if($i === $current): ?>
                <span style="<?php echo e($active); ?>"><?php echo e($i); ?></span>
            <?php else: ?>
                <a href="<?php echo e($paginator->url($i)); ?>" style="<?php echo e($btn); ?>"><?php echo e($i); ?></a>
            <?php endif; ?>
        <?php endfor; ?>

        <?php if($end < $last): ?>
            <?php if($end < $last - 1): ?> <span>…</span> <?php endif; ?>
            <a href="<?php echo e($paginator->url($last)); ?>" style="<?php echo e($btn); ?>"><?php echo e($last); ?></a>
        <?php endif; ?>

        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>" style="<?php echo e($btn); ?>">بعدی</a>
        <?php else: ?>
            <span style="<?php echo e($off); ?>">بعدی</span>
        <?php endif; ?>
    </nav>
<?php endif; ?>
<?php /**PATH D:\ZahraFiles\company-assets\resources\views/partials/simple-pagination.blade.php ENDPATH**/ ?>