

<?php $__env->startSection('content'); ?>

<div class="max-w-3xl mx-auto space-y-8">

    <!-- تاریخچه کامنت‌ها -->
    <div class="bg-white shadow-md rounded-lg p-6 border">
        <h3 class="text-xl font-bold text-gray-800 mb-5">
            تاریخچه کامنت‌ها
        </h3>

        <?php if($asset->comments->count() > 0): ?>
            <ul class="space-y-5">
                <?php $__currentLoopData = $asset->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="border-b pb-5 last:border-b-0 last:pb-0">
                        <div class="flex justify-between items-center mb-2">
                            <span class="font-bold text-gray-800 text-lg">
                                <?php echo e($comment->user->name); ?>

                            </span>
                            <span class="text-sm text-gray-500">
                                <?php echo e($comment->created_at->format('Y-m-d H:i')); ?>

                            </span>
                        </div>
                        <p class="text-gray-700 leading-relaxed text-base">
                            <?php echo e($comment->comment); ?>

                        </p>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <p class="text-gray-500 text-center py-8">
                هنوز کامنتی برای این مال ثبت نشده است.
            </p>
        <?php endif; ?>
    </div>

    <!-- فرم ثبت کامنت جدید -->
    <div class="bg-white shadow-md rounded-lg p-6 border">
        <h3 class="text-xl font-bold text-gray-800 mb-5">
            افزودن کامنت جدید
        </h3>

        <form action="<?php echo e(route('comments.store', $asset)); ?>" method="POST" class="space-y-5">
            <?php echo csrf_field(); ?>

            <div>
                <label for="comment_text" class="block text-sm font-medium text-gray-700 mb-2">
                    کامنت شما
                </label>
                <textarea
                    name="comment"
                    id="comment_text"
                    rows="6"
                    class="w-full border border-gray-300 rounded-lg p-3 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 text-base placeholder-gray-400"
                    required
                    placeholder="نوشتن کامنت..."
                ><?php echo e(old('comment')); ?></textarea>

                <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 text-sm mt-2"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- دکمه‌ها -->
            <div class="flex items-center justify-between pt-4">
                <button
                    type="submit"
                    class="bg-indigo-600 hover:bg-indigo-700 font-bold py-3 px-6 rounded-lg shadow-lg transition duration-300 ease-in-out">
                    ثبت کامنت
                </button>

                
                
                <a href="<?php echo e(route('admin.users.showUserAssets', $user)); ?>"
                   class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-3 px-6 rounded-lg shadow transition duration-300 ease-in-out">
                    بازگشت به صفحه کاربر
                </a>
            </div>
        </form>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\ZahraFiles\company-assets\resources\views/admin/edit-comment.blade.php ENDPATH**/ ?>