<?php $__env->startSection('content'); ?>

<div class="flex justify-between items-center mb-6">
    <h2 class="text-2xl font-bold text-gray-800">واحد انبار</h2>
    <a href="<?php echo e(route('warehouse.assets.create')); ?>"
       class="bg-green-500 hover:bg-green-600 text-white px-5 py-2 rounded shadow transition duration-200">
        + ثبت مال جدید در انبار
    </a>
</div>

<?php if($errors->any()): ?>
    <div class="p-3 rounded mb-4" style="background-color:#fecaca;color:#991b1b;">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div><?php echo e($error); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>


<div class="bg-white rounded-lg shadow p-6 mb-8">
    <h3 class="text-lg font-bold text-gray-800 mb-1">۱) خارج کردن مال از مالکیت کاربر</h3>
    <p class="text-gray-600 text-sm mb-4">
        شماره اموال را جستجو کنید؛ با خارج کردن مال از مالکیت، مال بدون کاربر در انبار قرار می‌گیرد.
    </p>

    <form action="<?php echo e(route('warehouse.index')); ?>" method="GET" class="flex flex-wrap items-center gap-3 mb-4">
        <input type="text" name="q" value="<?php echo e($q); ?>" placeholder="شماره اموال..."
               class="border border-gray-300 rounded px-3 py-1 w-48" autofocus>
        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded shadow">جستجو</button>
        <?php if($q !== ''): ?>
            <a href="<?php echo e(route('warehouse.index')); ?>" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-1 rounded shadow">پاک کردن</a>
        <?php endif; ?>
    </form>

    <?php if($q !== ''): ?>
        <div class="overflow-x-auto">
            <table class="min-w-full border border-gray-200 rounded-lg">
                <thead class="bg-gray-100 border-b border-gray-200">
                    <tr>
                        <th class="text-center p-3 font-medium text-gray-700">عنوان</th>
                        <th class="text-center p-3 font-medium text-gray-700">شماره اموال</th>
                        <th class="text-center p-3 font-medium text-gray-700">تعداد</th>
                        <th class="text-center p-3 font-medium text-gray-700">توضیحات</th>
                        <th class="text-center p-3 font-medium text-gray-700">مالک فعلی</th>
                        <th class="text-center p-3 font-medium text-gray-700">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $found; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="p-3 text-center text-gray-800"><?php echo e($asset->title); ?></td>
                            <td class="p-3 text-center text-gray-800"><?php echo e($asset->asset_number); ?></td>
                            <td class="p-3 text-center text-gray-800"><?php echo e($asset->count); ?></td>
                            <td class="p-3 text-center text-gray-800"><?php echo e($asset->description); ?></td>
                            <td class="p-3 text-center text-gray-800">
                                <?php if($asset->user): ?>
                                    <?php echo e($asset->user->name); ?>

                                    <div class="text-xs text-gray-500">
                                        <?php echo e($asset->user->unit); ?>

                                        <?php if($asset->user->room_number): ?> - اتاق <?php echo e($asset->user->room_number); ?> <?php endif; ?>
                                        <?php if($asset->user->floor): ?> - <?php echo e($asset->user->floor); ?> <?php endif; ?>
                                    </div>
                                <?php else: ?>
                                    <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">در انبار (بدون مالک)</span>
                                <?php endif; ?>
                            </td>
                            <td class="p-3 text-center">
                                <?php if($asset->user): ?>
                                    <form action="<?php echo e(route('warehouse.release', $asset)); ?>" method="POST" class="inline"
                                          onsubmit="return confirm(<?php echo \Illuminate\Support\Js::from('مال شماره ' . $asset->asset_number . ' از مالکیت «' . $asset->user->name . '» خارج و به انبار منتقل شود؟')->toHtml() ?>);">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="q" value="<?php echo e($q); ?>">
                                        <button type="submit" class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded shadow text-sm">
                                            خارج کردن از مالکیت
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <span class="text-gray-400 text-sm">—</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="p-4 text-center text-gray-500">مالی با این شماره پیدا نشد.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>


<div class="bg-white rounded-lg shadow p-6">
    <h3 class="text-lg font-bold text-gray-800 mb-1">۲) اموال بدون مالک (موجود در انبار)</h3>
    <p class="text-gray-600 text-sm mb-4">
        برای مثال «میز» را در عنوان جستجو کنید، یک یا چند مال را انتخاب کنید و به کاربر مورد نظر اختصاص دهید.
    </p>

    
    <form action="<?php echo e(route('warehouse.index')); ?>" method="GET" class="flex flex-wrap items-center gap-3 mb-4">
        <?php if($q !== ''): ?><input type="hidden" name="q" value="<?php echo e($q); ?>"><?php endif; ?>
        <input type="text" name="title" value="<?php echo e($title); ?>" placeholder="عنوان (مثلاً میز)..."
               class="border border-gray-300 rounded px-3 py-1 w-48">
        <input type="text" name="number" value="<?php echo e($number); ?>" placeholder="شماره اموال..."
               class="border border-gray-300 rounded px-3 py-1 w-48">
        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded shadow">فیلتر</button>
        <?php if($title !== '' || $number !== ''): ?>
            <a href="<?php echo e(route('warehouse.index', array_filter(['q' => $q]))); ?>" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-1 rounded shadow">نمایش همه</a>
        <?php endif; ?>
        <span class="text-gray-600 text-sm">تعداد نتایج: <?php echo e($unowned->total()); ?></span>
    </form>

    
    <form action="<?php echo e(route('warehouse.assign')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="overflow-x-auto">
            <table class="min-w-full border border-gray-200 rounded-lg">
                <thead class="bg-gray-100 border-b border-gray-200">
                    <tr>
                        <th class="text-center p-3 font-medium text-gray-700">
                            <input type="checkbox" id="check-all" title="انتخاب همه‌ی این صفحه">
                        </th>
                        <th class="text-center p-3 font-medium text-gray-700">عنوان</th>
                        <th class="text-center p-3 font-medium text-gray-700">شماره اموال</th>
                        <th class="text-center p-3 font-medium text-gray-700">تعداد</th>
                        <th class="text-center p-3 font-medium text-gray-700">توضیحات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $unowned; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="p-3 text-center">
                                <input type="checkbox" name="asset_ids[]" value="<?php echo e($asset->id); ?>" class="asset-check"
                                       <?php if(is_array(old('asset_ids')) && in_array($asset->id, old('asset_ids'))): echo 'checked'; endif; ?>>
                            </td>
                            <td class="p-3 text-center text-gray-800"><?php echo e($asset->title); ?></td>
                            <td class="p-3 text-center text-gray-800"><?php echo e($asset->asset_number); ?></td>
                            <td class="p-3 text-center text-gray-800"><?php echo e($asset->count); ?></td>
                            <td class="p-3 text-center text-gray-800"><?php echo e($asset->description); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="p-4 text-center text-gray-500">مالِ بدون مالکی وجود ندارد.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($unowned->count() > 0): ?>
            <div class="flex flex-wrap items-center gap-3 mt-4">
                <input type="text" id="user-filter" placeholder="جستجوی کاربر..."
                       class="border border-gray-300 rounded px-3 py-1 w-48">

                <select name="user_id" id="user-select" class="border border-gray-300 rounded px-3 py-1 w-72">
                    <option value="">-- انتخاب کاربر --</option>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($u->id); ?>" <?php if(old('user_id') == $u->id): echo 'selected'; endif; ?>>
                            <?php echo e($u->name); ?><?php if($u->unit): ?> - <?php echo e($u->unit); ?><?php endif; ?> <?php if($u->room_number): ?> - اتاق <?php echo e($u->room_number); ?><?php endif; ?>
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <button type="submit"
                        onclick="return confirm('مال‌های انتخاب‌شده به کاربر انتخاب‌شده اختصاص داده شود؟');"
                        class="bg-green-500 hover:bg-green-600 text-white px-5 py-2 rounded shadow">
                    اختصاص به کاربر
                </button>
            </div>
        <?php endif; ?>
    </form>

    <div class="mt-4">
        <?php echo $__env->make('partials.simple-pagination', ['paginator' => $unowned], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>

<script>
    // انتخاب همه‌ی اموال صفحه
    const checkAll = document.getElementById('check-all');
    if (checkAll) {
        checkAll.addEventListener('change', function () {
            document.querySelectorAll('.asset-check').forEach(function (c) { c.checked = checkAll.checked; });
        });
    }

    // فیلتر سریع لیست کاربران
    const userFilter = document.getElementById('user-filter');
    const userSelect = document.getElementById('user-select');
    if (userFilter && userSelect) {
        userFilter.addEventListener('input', function () {
            const term = userFilter.value.trim();
            Array.from(userSelect.options).forEach(function (opt, i) {
                if (i === 0) return;
                const match = term === '' || opt.text.indexOf(term) !== -1;
                opt.hidden = !match;
                opt.disabled = !match;
            });
        });
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\ZahraFiles\company-assets\resources\views/warehouse/index.blade.php ENDPATH**/ ?>