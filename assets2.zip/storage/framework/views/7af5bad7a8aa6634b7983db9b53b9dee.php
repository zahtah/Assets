

<?php $__env->startSection('content'); ?>


<div class="max-w-4xl mx-auto space-y-8">

    <!-- عنوان صفحه -->
    <h2 class="text-2xl font-bold text-gray-800 mb-4">
        جزئیات مال و ثبت کامنت
    </h2>

    <!-- کارت اطلاعات مال -->
    <div class="bg-white shadow-md rounded-lg p-6 border">
        <h3 class="text-lg font-semibold text-gray-700 mb-4">
            اطلاعات مال
        </h3>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

            <!-- عنوان مال -->
            <div>
                <label class="block text-sm text-gray-500 mb-1">عنوان مال</label>
                <p class="bg-gray-100 border rounded p-3"><?php echo e($asset->title); ?></p>
            </div>

            <!-- شماره اموال -->
            <div>
                <label class="block text-sm text-gray-500 mb-1">شماره اموال</label>
                <p class="bg-gray-100 border rounded p-3"><?php echo e($asset->asset_number); ?></p>
            </div>

            <!-- ستاد -->
            <div>
                <label class="block text-sm text-gray-500 mb-1">ستاد</label>
                <p class="bg-gray-100 border rounded p-3"><?php echo e($asset->city); ?></p>
            </div>

            <!-- تاریخ بروزرسانی -->
            <div>
                <label class="block text-sm text-gray-500 mb-1">تاریخ بروزرسانی</label>
                <p class="bg-gray-100 border rounded p-3">
                    <?php echo e(\Morilog\Jalali\Jalalian::fromCarbon(\Carbon\Carbon::parse($asset->updated_at_date))->format('Y/m/d')); ?>

                </p>
            </div>
        </div>
    </div>

    <!-- تاریخچه کامنت‌ها -->
    <div class="bg-white shadow-md rounded-lg p-6 border">
        <h3 class="text-lg font-semibold text-gray-700 mb-4">
            تاریخچه کامنت‌ها
        </h3>

        <?php if($asset->comments->count() > 0): ?>
            <ul class="space-y-4">
                <?php $__currentLoopData = $asset->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="border rounded p-4 bg-gray-50">
                        <div class="flex justify-between mb-2">
                            <span class="font-bold text-gray-800"><?php echo e($comment->user->name); ?></span>
                            <span class="text-sm text-gray-500">
                                <?php echo e($comment->created_at->format('Y-m-d H:i')); ?>

                            </span>
                        </div>
                        <p class="text-gray-700 leading-relaxed">
                            <?php echo e($comment->comment); ?>

                        </p>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <p class="text-gray-500">هنوز کامنتی ثبت نشده است.</p>
        <?php endif; ?>
    </div>

    <!-- فرم ثبت کامنت جدید -->
    <div class="bg-white shadow-md rounded-lg p-6 border">
        <h3 class="text-lg font-semibold text-gray-700 mb-4">
            افزودن کامنت جدید
        </h3>

        <form action="<?php echo e(route('comments.store', [$asset])); ?>" method="POST" class="space-y-4">
            <?php echo csrf_field(); ?>

            <div>
                <label for="comment_text" class="block text-sm text-gray-600 mb-1">کامنت شما</label>
                <textarea 
                    name="comment" 
                    id="comment_text"
                    rows="5"
                    class="w-full border rounded p-3 focus:ring focus:ring-blue-300"
                    required><?php echo e(old('comment')); ?></textarea>

                <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <!-- دکمه‌ها -->
            <div class="flex items-center space-x-3 space-x-reverse mt-4">

                <button 
                    type="submit" 
                    class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded shadow">
                    ثبت کامنت
                </button>

                <a href="<?php echo e(route('assets.index')); ?>"
                   class="bg-gray-300 hover:bg-gray-400 text-black px-6 py-2 rounded shadow">
                   بازگشت
                </a>

            </div>
        </form>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\ZahraFiles\company-assets\resources\views/assets/edit.blade.php ENDPATH**/ ?>