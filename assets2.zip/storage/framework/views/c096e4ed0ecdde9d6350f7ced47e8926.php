<?php $__env->startSection('content'); ?>

<div class="flex justify-between items-center mb-6">
    <h2 class="text-2xl font-bold text-gray-800">اموال ویرایش‌شده (همه‌ی کاربران)</h2>
    <a href="<?php echo e(route('all-users')); ?>"
       class="bg-gray-500 hover:bg-gray-600 text-white px-5 py-2 rounded shadow transition duration-200">
        بازگشت به لیست کاربران
    </a>
</div>


<div class="bg-white rounded-lg shadow p-6 mb-6">
    <form action="<?php echo e(route('admin.edited-assets')); ?>" method="GET" class="flex flex-wrap items-end gap-3">
        <div>
            <label class="block text-sm text-gray-600 mb-1">از تاریخ (شمسی)</label>
            <input type="text" name="from" value="<?php echo e(request('from')); ?>" placeholder="1405/07/01"
                   class="border border-gray-300 rounded px-3 py-1 w-36">
        </div>
        <div>
            <label class="block text-sm text-gray-600 mb-1">تا تاریخ (شمسی)</label>
            <input type="text" name="to" value="<?php echo e(request('to')); ?>" placeholder="1405/07/30"
                   class="border border-gray-300 rounded px-3 py-1 w-36">
        </div>
        <div>
            <label class="block text-sm text-gray-600 mb-1">نام کاربر (مالک)</label>
            <input type="text" name="user" value="<?php echo e(request('user')); ?>" placeholder="نام کاربر..."
                   class="border border-gray-300 rounded px-3 py-1 w-44">
        </div>
        <div>
            <label class="block text-sm text-gray-600 mb-1">شماره اموال</label>
            <input type="text" name="number" value="<?php echo e(request('number')); ?>" placeholder="شماره اموال..."
                   class="border border-gray-300 rounded px-3 py-1 w-40">
        </div>
        <div>
            <label class="block text-sm text-gray-600 mb-1">نوع تغییر</label>
            <select name="action" class="border border-gray-300 rounded px-3 py-1 w-56">
                <option value="">همه</option>
                <?php $__currentLoopData = $actionLabels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>" <?php if(request('action') === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded shadow">اعمال فیلتر</button>
        <?php if(request()->hasAny(['from','to','user','number','action']) && collect(request()->only(['from','to','user','number','action']))->filter()->isNotEmpty()): ?>
            <a href="<?php echo e(route('admin.edited-assets')); ?>" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-1 rounded shadow">نمایش همه</a>
        <?php endif; ?>
    </form>

    <?php if($invalidDates): ?>
        <div class="p-3 rounded mt-4" style="background-color:#fecaca;color:#991b1b;">
            تاریخ واردشده نامعتبر است؛ فرمت صحیح مانند 1405/07/21 است. (فیلتر تاریخ نامعتبر نادیده گرفته شد)
        </div>
    <?php endif; ?>
</div>

<div class="text-gray-600 text-sm mb-3">
    تعداد اموال ویرایش‌شده در این نتیجه: <?php echo e($assets->total()); ?>

    — برای دیدن تغییرات و کامنت‌های هر مال، روی ردیف آن کلیک کنید.
</div>

<div class="overflow-x-auto shadow rounded-lg">
    <table class="min-w-full bg-white">
        <thead class="bg-gray-100 border-b">
            <tr>
                <th class="text-center p-3 font-medium text-gray-700">کاربر (مالک فعلی)</th>
                <th class="text-center p-3 font-medium text-gray-700">عنوان مال</th>
                <th class="text-center p-3 font-medium text-gray-700">شماره اموال</th>
                <th class="text-center p-3 font-medium text-gray-700">آخرین تغییر</th>
                <th class="text-center p-3 font-medium text-gray-700">نوع آخرین تغییر</th>
                <th class="text-center p-3 font-medium text-gray-700">انجام‌دهنده</th>
                <th class="text-center p-3 font-medium text-gray-700">تعداد تغییرات</th>
                <th class="text-center p-3 font-medium text-gray-700">کامنت</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $last = $lastEdits[$asset->id] ?? null;
                    $url = $asset->user_id
                        ? route('admin.users.showUserAssets', [$asset->user_id, 'highlight' => $asset->id]) . '#asset-' . $asset->id
                        : route('warehouse.index', ['q' => $asset->asset_number]);
                ?>
                <tr class="border-b hover:bg-gray-50 transition duration-150" style="cursor:pointer;"
                    onclick="window.location='<?php echo e($url); ?>'">
                    <td class="p-3 text-center text-gray-800">
                        <?php if($asset->user): ?>
                            <a href="<?php echo e($url); ?>" class="text-blue-600 hover:text-blue-800 font-medium"><?php echo e($asset->user->name); ?></a>
                            <div class="text-xs text-gray-500"><?php echo e($asset->user->unit); ?></div>
                        <?php else: ?>
                            <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">در انبار</span>
                        <?php endif; ?>
                    </td>
                    <td class="p-3 text-center text-gray-800"><?php echo e($asset->title); ?></td>
                    <td class="p-3 text-center text-gray-800"><?php echo e($asset->asset_number); ?></td>
                    <td class="p-3 text-center text-gray-800"><?php echo e(\App\Support\Jalali::dateTime($asset->last_edit_at)); ?></td>
                    <td class="p-3 text-center text-gray-800">
                        <?php echo e($last?->action_label ?? '—'); ?>

                        <?php if($last && $last->action === 'release' && $last->previousOwner): ?>
                            <div class="text-xs text-gray-500">از: <?php echo e($last->previousOwner->name); ?></div>
                        <?php endif; ?>
                    </td>
                    <td class="p-3 text-center text-gray-800"><?php echo e($last?->editor?->name ?? '—'); ?></td>
                    <td class="p-3 text-center text-gray-800"><?php echo e($asset->edits_in_range); ?></td>
                    <td class="p-3 text-center text-gray-800">
                        <?php if($asset->admin_new_comment): ?>
                            <span style="display:inline-block;background-color:#ffebee;color:#c62828;padding:2px 8px;border-radius:4px;font-size:0.75rem;font-weight:bold;">
                                &#9888;&#xFE0F; نظر جدید
                            </span>
                        <?php endif; ?>
                        <?php if($asset->comments_count > 0): ?>
                            <span class="text-xs text-gray-600"><?php echo e($asset->comments_count); ?> کامنت</span>
                        <?php else: ?>
                            <span class="text-xs text-gray-400">—</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="p-4 text-center text-gray-500">مالِ ویرایش‌شده‌ای در این بازه پیدا نشد.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php echo $__env->make('partials.simple-pagination', ['paginator' => $assets], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\ZahraFiles\company-assets\resources\views/admin/edited-assets.blade.php ENDPATH**/ ?>