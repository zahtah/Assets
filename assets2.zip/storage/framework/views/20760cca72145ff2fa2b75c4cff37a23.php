

<?php $__env->startSection('content'); ?>

<?php
    $currentUser = Auth::user();
?>

<div class="flex flex-col md:flex-row justify-between items-center mb-6">
    <h2 class="text-2xl font-bold text-gray-800 mb-4 md:mb-0">اموال من</h2>
    <?php if($currentUser && $currentUser->allow_editing): ?>
        <a href="<?php echo e(route('assets.create')); ?>"
        class="bg-blue-500 hover:bg-blue-600 text-white px-5 py-2 rounded shadow transition duration-200">
            ثبت مال جدید
        </a>
    <?php endif; ?>
</div>




<div class="overflow-x-auto ">
    <table class="min-w-full bg-white shadow rounded-lg table-fixed" >
        <thead class="bg-gray-100 border-b">
            <tr>
                <th class="w-1/7 text-center p-3 font-medium text-gray-700">عنوان</th>
                <th class="w-1/7 text-center p-3 font-medium text-gray-700">شماره</th>
                <th class="text-center p-3 font-medium text-gray-700">تعداد</th>
                <th class="text-center p-3 font-medium text-gray-700">توضیحات</th>
                <th class="w-1/7 text-center p-3 font-medium text-gray-700">تاریخ ثبت</th>
                
                <th class="w-1/7 text-center p-3 font-medium text-gray-700">وضعیت تایید کاربر</th>
                <th class="w-1/7 text-center p-3 font-medium text-gray-700">وضعیت تایید ادمین</th>
                <th class="w-1/7 text-center p-3 font-medium text-gray-700">عملیات</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-b hover:bg-gray-50 transition duration-150">
                    <td class="p-3 text-gray-800 text-center"><?php echo e($asset->title); ?></td>
                    <td class="p-3 text-gray-800 text-center"><?php echo e($asset->asset_number); ?></td>
                    <td class="p-3 text-gray-800 text-center"><?php echo e($asset->count); ?></td>
                    <td class="p-3 text-gray-800 text-center"><?php echo e($asset->description); ?></td>
                    <td class="p-3 text-gray-800 text-center">
                        <?php echo e(\Morilog\Jalali\Jalalian::fromCarbon(\Carbon\Carbon::parse($asset->updated_at_date))->format('Y/m/d')); ?>

                    </td>
                    <td class="p-3 text-gray-800 text-center flex justify-center items-center">
                    <span class="ml-2">
                    <?php if($asset->user_approved): ?>
                        <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">تأیید شده توسط کاربر</span>
                    <?php else: ?>
                        <span class="bg-red-100 text-red-800 px-2 py-1 rounded text-xs">عدم تأیید کاربر</span>
                    <?php endif; ?>
                    </span>
                    <span>
                        <form action="<?php echo e(route('assets.toggleUserApproval', $asset)); ?>" method="POST">
                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                            <button type="submit"
                                class="<?php echo e($asset->user_approved ? 'bg-red-500 hover:bg-red-600' : 'bg-green-500 hover:bg-green-600'); ?>

                                        text-white px-3 py-1 rounded">
                                <?php echo e($asset->user_approved ? 'لغو تأیید' : 'تأیید'); ?>

                            </button>
                        </form>
                    </span>
                    </td>
                    <td class="p-3 text-gray-800 text-center">
                        <?php if($asset->admin_approved): ?>
                            <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">تأیید شده توسط ادمین</span>
                        <?php else: ?>
                            <span class="bg-red-100 text-red-800 px-2 py-1 rounded text-xs">عدم تأیید ادمین</span>
                        <?php endif; ?>
                    </td>
                    
                    
                        <td class="p-3 text-center">
                            <?php if($asset->user_new_comment): ?>
                                <span style="width:10px;height:10px;background:red;border-radius:50%;display:inline-block;"></span>
                            <?php endif; ?>
                            <a href="<?php echo e(route('assets.edit',$asset)); ?>"
                            class="text-blue-600 hover:text-blue-800 font-medium mr-2">کامنت</a>
                            
                            
                        </td>
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="p-4 text-center text-gray-500">
                        هنوز مال ثبت نشده است.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>





<?php if($currentUser->show_contract_button): ?> 
    
    
    
    

        <a href="<?php echo e(route('users.contract', $currentUser->id)); ?>" target="_blank"
           class="inline-block bg-green-100 text-green-800 px-4 py-2 mt-4 rounded-md hover:bg-indigo-700 transition">
           📝 مشاهده قرارداد اموال
        </a>

    
<?php endif; ?>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\ZahraFiles\company-assets\resources\views/assets/index.blade.php ENDPATH**/ ?>