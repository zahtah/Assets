

<?php $__env->startSection('content'); ?>
<div class="w-full">
    <div class="bg-white rounded-lg shadow p-6">

        <h4 class="text-xl font-bold mb-6">ویرایش کاربر</h4>

        <form method="POST" action="<?php echo e(route('update-user', $user->id)); ?>" class="space-y-4">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <div>
                <label for="name" class="block text-gray-700 mb-1">نام</label>
                <input id="name" name="name" type="text"
                       placeholder="Enter User Name"
                       value="<?php echo e(old('name', $user->name)); ?>"
                       class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring focus:ring-blue-300">
            </div>

            <div>
                <label for="email" class="block text-gray-700 mb-1">نام کاربری</label>
                <input id="email" name="email" type="text"
                       placeholder="Enter User Email"
                       value="<?php echo e(old('email', $user->email)); ?>"
                       class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring focus:ring-blue-300">
            </div>

            
            <div>
                <label for="department" class="block text-gray-700 mb-1">ساختمان</label>
                <select id="department" name="department"
                       class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring focus:ring-blue-300">
                    <?php
                        $current = old('department', $user->department);
                    ?>
                    <?php $__currentLoopData = ['ستاد','امور منابع آب مهدیشهر','امور منابع آب سمنان','امور منابع آب شاهرود','امور منابع آب دامغان','امور منابع آب گرمسار','امور منابع آب میامی']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($dep); ?>" <?php echo e($current == $dep ? 'selected' : ''); ?>><?php echo e($dep); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label for="unit" class="block text-gray-700 mb-1">واحد</label>
                <select id="unit" name="unit"
                        class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring focus:ring-blue-300">

                    <?php
                        $current = old('unit', $user->unit);
                    ?>

                    <option value="برنامه ریزی" <?php echo e($current == 'برنامه ریزی' ? 'selected' : ''); ?>>برنامه ریزی</option>
                    <option value="حفاظت" <?php echo e($current == 'حفاظت' ? 'selected' : ''); ?>>حفاظت</option>
                    <option value="IT" <?php echo e($current == 'IT' ? 'selected' : ''); ?>>IT</option>
                    <option value="مالی" <?php echo e($current == 'مالی' ? 'selected' : ''); ?>>مالی</option>
                    <option value="مدیریت" <?php echo e($current == 'مدیریت' ? 'selected' : ''); ?>>مدیریت</option>
                    <option value="مطالعات" <?php echo e($current == 'مطالعات' ? 'selected' : ''); ?>>مطالعات</option>
                    <option value="طرح و توسعه" <?php echo e($current == 'طرح و توسعه' ? 'selected' : ''); ?>>طرح و توسعه</option>
                    <option value="انبار" <?php echo e($current == 'انبار' ? 'selected' : ''); ?>>انبار</option>

                </select>
            </div>

            <div>
                <label for="room_number" class="block text-gray-700 mb-1">شماره اتاق</label>
                <input id="room_number" name="room_number" type="number"
                       placeholder="Enter User Room Number"
                       value="<?php echo e(old('room_number', $user->room_number)); ?>"
                       class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring focus:ring-blue-300">
            </div>

            <div>
                <label for="floor" class="block text-gray-700 mb-1">طبقه</label>
                <?php
                    $currentFloor = old('floor', $user->floor);
                ?>
                <select id="floor" name="floor"
                        class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring focus:ring-blue-300">
                    <option value="">-- انتخاب طبقه --</option>
                    <?php $__currentLoopData = \App\Models\User::FLOORS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $floorOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($floorOption); ?>" <?php echo e($currentFloor === $floorOption ? 'selected' : ''); ?>><?php echo e($floorOption); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php if($currentFloor && !in_array($currentFloor, \App\Models\User::FLOORS, true)): ?>
                        <option value="<?php echo e($currentFloor); ?>" selected><?php echo e($currentFloor); ?> (مقدار قبلی)</option>
                    <?php endif; ?>
                </select>
                <?php $__errorArgs = ['floor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <?php if($user->role !== 'admin'): ?>
            <div>
                <label for="role" class="block text-gray-700 mb-1">نوع دسترسی</label>
                <?php
                    $currentRole = old('role', $user->role);
                ?>
                <select id="role" name="role"
                        class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring focus:ring-blue-300">
                    <?php $__currentLoopData = \App\Models\User::ASSIGNABLE_ROLES; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roleKey => $roleLabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($roleKey); ?>" <?php echo e($currentRole === $roleKey ? 'selected' : ''); ?>><?php echo e($roleLabel); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <?php endif; ?>


            <div>
                <label for="password" class="block text-gray-700 mb-1">پسورد</label>
                <input id="password" name="password" type="password"
                       placeholder="Enter User Password"
                       class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring focus:ring-blue-300">
            </div>

            <div>
                <label for="password_confirmation" class="block text-gray-700 mb-1">تکرار پسورد</label>
                <input id="password_confirmation" name="password_confirmation" type="password"
                       placeholder="Retype the Password"
                       class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring focus:ring-blue-300">
            </div>

            

            <button type="submit"
                    class="px-5 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700 transition mt-2">
                ثبت
            </button>
            <a href="<?php echo e(route('all-users')); ?>" class="ml-2 bg-gray-300 text-black px-4 py-2 rounded">انصراف</a>

        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\ZahraFiles\company-assets\resources\views/admin/users/edit-user.blade.php ENDPATH**/ ?>