@extends('layouts.app')

@section('content')

@php
    $currentUser = Auth::user();
@endphp

<div class="flex flex-col md:flex-row justify-between items-center mb-6">
    <h2 class="text-2xl font-bold text-gray-800 mb-4 md:mb-0">اموال من</h2>
    @if ($currentUser && $currentUser->allow_editing)
        <a href="{{ route('assets.create') }}"
        class="bg-blue-500 hover:bg-blue-600 text-white px-5 py-2 rounded shadow transition duration-200">
            ثبت مال جدید
        </a>
    @endif
</div>

{{-- پیام موفقیت --}}
{{-- @if(session('success'))
    <div class="mb-4 p-3 bg-green-100 text-green-700 rounded shadow">
        {{ session('success') }}
    </div>
@endif --}}

<div class="overflow-x-auto ">
    <table class="min-w-full bg-white shadow rounded-lg table-fixed" >
        <thead class="bg-gray-100 border-b">
            <tr>
                <th class="w-1/7 text-center p-3 font-medium text-gray-700">عنوان</th>
                <th class="w-1/7 text-center p-3 font-medium text-gray-700">شماره</th>
                <th class="text-center p-3 font-medium text-gray-700">تعداد</th>
                <th class="text-center p-3 font-medium text-gray-700">توضیحات</th>
                <th class="w-1/7 text-center p-3 font-medium text-gray-700">تاریخ ثبت</th>
                {{-- <th class="w-1/6 text-center p-3 font-medium text-gray-700">نام هاست</th> --}}
                <th class="w-1/7 text-center p-3 font-medium text-gray-700">وضعیت تایید کاربر</th>
                <th class="w-1/7 text-center p-3 font-medium text-gray-700">وضعیت تایید ادمین</th>
                <th class="w-1/7 text-center p-3 font-medium text-gray-700">عملیات</th>
            </tr>
        </thead>
        <tbody>
            @forelse($assets as $asset)
                <tr class="border-b hover:bg-gray-50 transition duration-150">
                    <td class="p-3 text-gray-800 text-center">{{ $asset->title }}</td>
                    <td class="p-3 text-gray-800 text-center">{{ $asset->asset_number }}</td>
                    <td class="p-3 text-gray-800 text-center">{{ $asset->count }}</td>
                    <td class="p-3 text-gray-800 text-center">{{ $asset->description }}</td>
                    <td class="p-3 text-gray-800 text-center">
                        {{ \Morilog\Jalali\Jalalian::fromCarbon(\Carbon\Carbon::parse($asset->updated_at_date))->format('Y/m/d') }}
                    </td>
                    <td class="p-3 text-gray-800 text-center flex justify-center items-center">
                    <span class="ml-2">
                    @if ($asset->user_approved)
                        <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">تأیید شده توسط کاربر</span>
                    @else
                        <span class="bg-red-100 text-red-800 px-2 py-1 rounded text-xs">عدم تأیید کاربر</span>
                    @endif
                    </span>
                    <span>
                        <form action="{{ route('assets.toggleUserApproval', $asset) }}" method="POST">
                            @csrf @method('PATCH')
                            <button type="submit"
                                class="{{ $asset->user_approved ? 'bg-red-500 hover:bg-red-600' : 'bg-green-500 hover:bg-green-600' }}
                                        text-white px-3 py-1 rounded">
                                {{ $asset->user_approved ? 'لغو تأیید' : 'تأیید' }}
                            </button>
                        </form>
                    </span>
                    </td>
                    <td class="p-3 text-gray-800 text-center">
                        @if ($asset->admin_approved)
                            <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">تأیید شده توسط ادمین</span>
                        @else
                            <span class="bg-red-100 text-red-800 px-2 py-1 rounded text-xs">عدم تأیید ادمین</span>
                        @endif
                    </td>
                    {{-- <td class="p-3 text-gray-800 text-center">{{ $log->hostname }}</td> --}}
                    {{-- @if ($currentUser && $currentUser->allow_editing) --}}
                        <td class="p-3 text-center">
                            @if ($asset->user_new_comment)
                                <span style="width:10px;height:10px;background:red;border-radius:50%;display:inline-block;"></span>
                            @endif
                            <a href="{{ route('assets.edit',$asset) }}"
                            class="text-blue-600 hover:text-blue-800 font-medium mr-2">کامنت</a>
                            {{-- <form action="{{ route('assets.destroy', $asset) }}" method="POST" class="inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit"
                                        onclick="return confirm('آیا مطمئن هستید که می‌خواهید این مال را حذف کنید؟')"
                                        class="text-red-600 hover:text-red-800 font-medium">
                                    حذف
                                </button>
                            </form> --}}
                            {{-- {{ $asset->comment }} --}}
                        </td>
                    {{-- @endif --}}
                </tr>
            @empty
                <tr>
                    <td colspan="5" class="p-4 text-center text-gray-500">
                        هنوز مال ثبت نشده است.
                    </td>
                </tr>
            @endforelse
        </tbody>
    </table>
</div>

{{-- در ویوی نمایش پروفایل کاربر --}}

{{-- این قسمت را در جایی قرار بده که میخواهی دکمه نمایش داده شود --}}

@if($currentUser->show_contract_button) {{-- شرط اول: آیا ادمین اجازه نمایش داده؟ --}}
    {{-- شرط دوم (اختیاری): آیا قرارداد قبلا تولید شده؟ --}}
    {{-- این بخش به نحوه پیاده سازی شما بستگی دارد. --}}
    {{-- مثلا اگر یک ستون 'contract_generated' در جدول users دارید: --}}
    {{-- @if($user->contract_generated) --}}

        <a href="{{ route('users.contract', $currentUser->id) }}" target="_blank"
           class="inline-block bg-green-100 text-green-800 px-4 py-2 mt-4 rounded-md hover:bg-indigo-700 transition">
           📝 مشاهده فرم اموال
        </a>

    {{-- @endif --}}
@endif


{{-- Pagination --}}
{{-- <div class="mt-4">
    {{ $assets->links('vendor.pagination.tailwind') }}
</div> --}}

@endsection