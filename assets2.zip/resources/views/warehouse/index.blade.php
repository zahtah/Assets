@extends('layouts.app')

@section('content')

<div class="flex justify-between items-center mb-6">
    <h2 class="text-2xl font-bold text-gray-800">واحد انبار</h2>
    <a href="{{ route('warehouse.assets.create') }}"
       class="bg-green-500 hover:bg-green-600 text-white px-5 py-2 rounded shadow transition duration-200">
        + ثبت مال جدید در انبار
    </a>
</div>

@if($errors->any())
    <div class="p-3 rounded mb-4" style="background-color:#fecaca;color:#991b1b;">
        @foreach($errors->all() as $error)
            <div>{{ $error }}</div>
        @endforeach
    </div>
@endif

{{-- ===================== ۱) جستجوی مال و خارج کردن از مالکیت ===================== --}}
<div class="bg-white rounded-lg shadow p-6 mb-8">
    <h3 class="text-lg font-bold text-gray-800 mb-1">۱) خارج کردن مال از مالکیت کاربر</h3>
    <p class="text-gray-600 text-sm mb-4">
        شماره اموال را جستجو کنید؛ با خارج کردن مال از مالکیت، مال بدون کاربر در انبار قرار می‌گیرد.
    </p>

    <form action="{{ route('warehouse.index') }}" method="GET" class="flex flex-wrap items-center gap-3 mb-4">
        <input type="text" name="q" value="{{ $q }}" placeholder="شماره اموال..."
               class="border border-gray-300 rounded px-3 py-1 w-48" autofocus>
        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded shadow">جستجو</button>
        @if($q !== '')
            <a href="{{ route('warehouse.index') }}" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-1 rounded shadow">پاک کردن</a>
        @endif
    </form>

    @if($q !== '')
        <div class="overflow-x-auto">
            <table class="min-w-full border border-gray-200 rounded-lg">
                <thead class="bg-gray-100 border-b border-gray-200">
                    <tr>
                        <th class="text-center p-3 font-medium text-gray-700">عنوان</th>
                        <th class="text-center p-3 font-medium text-gray-700">شماره اموال</th>
                        <th class="text-center p-3 font-medium text-gray-700">تعداد</th>
                        <th class="text-center p-3 font-medium text-gray-700">توضیحات</th>
                        <th class="text-center p-3 font-medium text-gray-700">مالک فعلی</th>
                        <th class="text-center p-3 font-medium text-gray-700">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($found as $asset)
                        <tr class="border-b hover:bg-gray-50">
                            <td class="p-3 text-center text-gray-800">{{ $asset->title }}</td>
                            <td class="p-3 text-center text-gray-800">{{ $asset->asset_number }}</td>
                            <td class="p-3 text-center text-gray-800">{{ $asset->count }}</td>
                            <td class="p-3 text-center text-gray-800">{{ $asset->description }}</td>
                            <td class="p-3 text-center text-gray-800">
                                @if($asset->user)
                                    {{ $asset->user->name }}
                                    <div class="text-xs text-gray-500">
                                        {{ $asset->user->unit }}
                                        @if($asset->user->room_number) - اتاق {{ $asset->user->room_number }} @endif
                                        @if($asset->user->floor) - {{ $asset->user->floor }} @endif
                                    </div>
                                @else
                                    <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">در انبار (بدون مالک)</span>
                                @endif
                            </td>
                            <td class="p-3 text-center">
                                @if($asset->user)
                                    <form action="{{ route('warehouse.release', $asset) }}" method="POST" class="inline"
                                          onsubmit="return confirm(@js('مال شماره ' . $asset->asset_number . ' از مالکیت «' . $asset->user->name . '» خارج و به انبار منتقل شود؟'));">
                                        @csrf
                                        <input type="hidden" name="q" value="{{ $q }}">
                                        <button type="submit" class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded shadow text-sm">
                                            خارج کردن از مالکیت
                                        </button>
                                    </form>
                                @else
                                    <span class="text-gray-400 text-sm">—</span>
                                @endif
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="p-4 text-center text-gray-500">مالی با این شماره پیدا نشد.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    @endif
</div>

{{-- ===================== ۲) اموال بدون مالک و اختصاص به کاربر ===================== --}}
<div class="bg-white rounded-lg shadow p-6">
    <h3 class="text-lg font-bold text-gray-800 mb-1">۲) اموال بدون مالک (موجود در انبار)</h3>
    <p class="text-gray-600 text-sm mb-4">
        برای مثال «میز» را در عنوان جستجو کنید، یک یا چند مال را انتخاب کنید و به کاربر مورد نظر اختصاص دهید.
    </p>

    {{-- فیلتر لیست --}}
    <form action="{{ route('warehouse.index') }}" method="GET" class="flex flex-wrap items-center gap-3 mb-4">
        @if($q !== '')<input type="hidden" name="q" value="{{ $q }}">@endif
        <input type="text" name="title" value="{{ $title }}" placeholder="عنوان (مثلاً میز)..."
               class="border border-gray-300 rounded px-3 py-1 w-48">
        <input type="text" name="number" value="{{ $number }}" placeholder="شماره اموال..."
               class="border border-gray-300 rounded px-3 py-1 w-48">
        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded shadow">فیلتر</button>
        @if($title !== '' || $number !== '')
            <a href="{{ route('warehouse.index', array_filter(['q' => $q])) }}" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-1 rounded shadow">نمایش همه</a>
        @endif
        <span class="text-gray-600 text-sm">تعداد نتایج: {{ $unowned->total() }}</span>
    </form>

    {{-- فرم اختصاص (شامل چک‌باکس‌های جدول) --}}
    <form action="{{ route('warehouse.assign') }}" method="POST">
        @csrf

        <div class="overflow-x-auto">
            <table class="min-w-full border border-gray-200 rounded-lg">
                <thead class="bg-gray-100 border-b border-gray-200">
                    <tr>
                        <th class="text-center p-3 font-medium text-gray-700">
                            <input type="checkbox" id="check-all" title="انتخاب همه‌ی این صفحه">
                        </th>
                        <th class="text-center p-3 font-medium text-gray-700">عنوان</th>
                        <th class="text-center p-3 font-medium text-gray-700">شماره اموال</th>
                        <th class="text-center p-3 font-medium text-gray-700">تعداد</th>
                        <th class="text-center p-3 font-medium text-gray-700">توضیحات</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($unowned as $asset)
                        <tr class="border-b hover:bg-gray-50">
                            <td class="p-3 text-center">
                                <input type="checkbox" name="asset_ids[]" value="{{ $asset->id }}" class="asset-check"
                                       @checked(is_array(old('asset_ids')) && in_array($asset->id, old('asset_ids')))>
                            </td>
                            <td class="p-3 text-center text-gray-800">{{ $asset->title }}</td>
                            <td class="p-3 text-center text-gray-800">{{ $asset->asset_number }}</td>
                            <td class="p-3 text-center text-gray-800">{{ $asset->count }}</td>
                            <td class="p-3 text-center text-gray-800">{{ $asset->description }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="p-4 text-center text-gray-500">مالِ بدون مالکی وجود ندارد.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        @if($unowned->count() > 0)
            <div class="flex flex-wrap items-center gap-3 mt-4">
                <input type="text" id="user-filter" placeholder="جستجوی کاربر..."
                       class="border border-gray-300 rounded px-3 py-1 w-48">

                <select name="user_id" id="user-select" class="border border-gray-300 rounded px-3 py-1 w-72">
                    <option value="">-- انتخاب کاربر --</option>
                    @foreach($users as $u)
                        <option value="{{ $u->id }}" @selected(old('user_id') == $u->id)>
                            {{ $u->name }}@if($u->unit) - {{ $u->unit }}@endif @if($u->room_number) - اتاق {{ $u->room_number }}@endif
                        </option>
                    @endforeach
                </select>

                <button type="submit"
                        onclick="return confirm('مال‌های انتخاب‌شده به کاربر انتخاب‌شده اختصاص داده شود؟');"
                        class="bg-green-500 hover:bg-green-600 text-white px-5 py-2 rounded shadow">
                    اختصاص به کاربر
                </button>
            </div>
        @endif
    </form>

    <div class="mt-4">
        @include('partials.simple-pagination', ['paginator' => $unowned])
    </div>
</div>

<script>
    // انتخاب همه‌ی اموال صفحه
    const checkAll = document.getElementById('check-all');
    if (checkAll) {
        checkAll.addEventListener('change', function () {
            document.querySelectorAll('.asset-check').forEach(function (c) { c.checked = checkAll.checked; });
        });
    }

    // فیلتر سریع لیست کاربران
    const userFilter = document.getElementById('user-filter');
    const userSelect = document.getElementById('user-select');
    if (userFilter && userSelect) {
        userFilter.addEventListener('input', function () {
            const term = userFilter.value.trim();
            Array.from(userSelect.options).forEach(function (opt, i) {
                if (i === 0) return;
                const match = term === '' || opt.text.indexOf(term) !== -1;
                opt.hidden = !match;
                opt.disabled = !match;
            });
        });
    }
</script>

@endsection
