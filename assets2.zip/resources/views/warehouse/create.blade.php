@extends('layouts.app')

@section('content')
<div class="max-w-3xl mx-auto">
    <h2 class="text-2xl font-bold text-gray-800 mb-2">ثبت مال جدید در انبار</h2>
    <p class="text-gray-600 text-sm mb-6">این مال بدون مالک ثبت می‌شود و بعداً از صفحه‌ی انبار می‌توان آن را به کاربر اختصاص داد.</p>

    <form method="POST" action="{{ route('warehouse.assets.store') }}" class="bg-white p-6 rounded shadow">
        @csrf

        <div class="mb-4">
            <label class="block mb-1" for="title">عنوان مال</label>
            <input type="text" id="title" name="title" value="{{ old('title') }}" class="w-full border p-2 rounded" required autofocus>
            @error('title') <div class="text-red-600 mt-1">{{ $message }}</div> @enderror
        </div>

        <div class="mb-4">
            <label class="block mb-1" for="asset_number">شماره اموال</label>
            <input type="text" id="asset_number" name="asset_number" value="{{ old('asset_number') }}" class="w-full border p-2 rounded" required>
            @error('asset_number') <div class="text-red-600 mt-1">{{ $message }}</div> @enderror
        </div>

        <div class="mb-4">
            <label class="block mb-1" for="count">تعداد</label>
            <input type="number" id="count" name="count" min="1" value="{{ old('count', 1) }}" class="w-full border p-2 rounded">
            @error('count') <div class="text-red-600 mt-1">{{ $message }}</div> @enderror
        </div>

        <div class="mb-4">
            <label class="block mb-1" for="description">توضیحات</label>
            <input type="text" id="description" name="description" value="{{ old('description') }}" class="w-full border p-2 rounded">
            @error('description') <div class="text-red-600 mt-1">{{ $message }}</div> @enderror
        </div>

        <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded">ثبت</button>
        <button type="submit" name="add_another" value="1" class="bg-blue-500 text-white px-4 py-2 rounded">ثبت و افزودن مال بعدی</button>
        <a href="{{ route('warehouse.index') }}" class="bg-gray-300 text-black px-4 py-2 rounded">انصراف</a>
    </form>
</div>
@endsection
