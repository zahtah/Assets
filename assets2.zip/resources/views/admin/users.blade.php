@extends('layouts.app')

@section('content')

{{-- <div class="flex justify-between items-center mb-6">
    <h2 class="text-2xl font-bold text-gray-800">لیست کاربران</h2>
</div> --}}

<div class="flex justify-between items-center mb-6">
    <h2 class="text-2xl font-bold text-gray-800">لیست کاربران</h2>

    <!-- Search Form -->
    <form action="{{ route('admin.users') }}" method="GET" class="flex items-center gap-2">
        <div class="flex items-center gap-3">
            <input type="text"
                name="search"
                value="{{ request('search') }}"
                placeholder="جستجو بر اساس نام..."
                class="border border-gray-300 rounded px-3 py-1 focus:outline-none focus:ring focus:ring-blue-300">
            
            <button type="submit"
                    class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-1 rounded shadow">
                جستجو
            </button>
            @if(request()->has('search') && request('search') !== '')
                <a href="{{ route('admin.users') }}"
                class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-1 rounded shadow mr-4">
                نمایش همه
                </a>
            @endif
        </div>
    </form>
</div>


{{-- @if($newAlertsCount > 0)
    <div class="mb-4 text-center">
        <a href="{{ route('admin.alerts.index') }}"
           class="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded shadow relative">
            🔔 هشدار جدید ({{ $newAlertsCount }})
        </a>
    </div>
@endif --}}

{{-- پیام موفقیت --}}
@if(session('success'))
    <div class="mb-4 p-3 bg-green-100 text-green-700 rounded shadow">
        {{ session('success') }}
    </div>
@endif

<div class="overflow-x-auto shadow rounded-lg">
    <table class="min-w-full table-fixed bg-white" style="width: 100%;">
        <thead class="bg-gray-100 border-b">
            <tr>
                <th class="w-1/3 text-center p-3 font-medium text-gray-700">نام</th>
                {{-- <th class="w-1/3 text-center p-3 font-medium text-gray-700">ایمیل</th> --}}
                <th class="w-1/3 text-center p-3 font-medium text-gray-700">IP آخرین ورود</th>
                <th class="w-1/3 text-center p-3 font-medium text-gray-700">نام سیستم</th>
                <th class="w-1/3 text-center p-3 font-medium text-gray-700">تاریخ و ساعت آخرین ورود</th>
            </tr>
        </thead>
        <tbody>
            @forelse($users as $user)
                <tr class="border-b hover:bg-gray-50 transition duration-150">
                    <td class="p-3 text-center text-gray-800">
                         @if ($user->new_comment)
                            <span style="
                                display: inline-flex; /* استفاده از flex برای هم‌ترازی بهتر آیکون و متن */
                                align-items: center; /* عمودی وسط چین کردن */
                                background-color: #ffebee; /* پس‌زمینه قرمز روشن */
                                color: #c62828; /* رنگ متن و آیکون قرمز تیره */
                                padding: 2px 8px;
                                border-radius: 4px;
                                font-size: 0.75rem;
                                line-height: 1.2;
                                font-weight: bold;
                            ">
                                {{-- کاراکتر یونیکد علامت هشدار مثلثی --}}
                                &#9888;&#xFE0F; {{-- &#9888; = ⚠️ --}}
                                نظر جدید
                        </span>
                        @endif
                        {{ $user->name }}</td>
                    {{-- <td class="p-3 text-center text-gray-800">{{ $user->email }}</td> --}}
                    <td class="p-3 text-center text-gray-800">
                        {{ $user->latestLogin->ip_address ?? '—' }}
                    </td>

                    <td class="p-3 text-center text-gray-800">
                        {{ $user->latestLogin->hostname ?? '—' }}
                    </td>
                    {{-- <td class="p-3 text-center">
                        @if ($user->role!="admin")
                        <a href= "{{ route('admin.users.showUserAssets', $user->id) }}"
                           class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-1 rounded shadow transition duration-200">
                           مشاهده اموال
                        </a>
                        @endif
                    </td> --}}
                    <td class="p-3 text-center text-gray-800">
                         @if($user->last_login_at)
                            {{ \App\Support\Jalali::dateTime($user->last_login_at) }}
                         @else
                            <span class="text-gray-400">هنوز ورودی ثبت نشده</span>
                         @endif
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="4" class="p-4 text-center text-gray-500">
                        هیچ کاربری ثبت نشده است.
                    </td>
                </tr>
            @endforelse
        </tbody>
    </table>
</div>

{{-- Pagination --}}
<div class="mt-4">
    @include('partials.simple-pagination', ['paginator' => $users])
</div>

@endsection